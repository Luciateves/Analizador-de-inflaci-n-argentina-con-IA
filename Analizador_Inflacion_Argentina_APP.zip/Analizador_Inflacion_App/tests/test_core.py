from pathlib import Path
import sys
import io
import numpy as np
import pandas as pd
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from inflacion_core import (
    crear_demo, desde_csv, normalizar, indicadores, anomalias, calcular_pronostico,
    resumen, calcular_variacion_real, pdf_resumen, descargar_datos
)


def test_indicadores_basicos():
    dates = pd.date_range("2020-12-01", periods=38, freq="MS")
    data = normalizar(pd.DataFrame({"fecha": dates, "ipc": 100 * 1.02 ** np.arange(38)}))
    res = indicadores(data)
    assert np.isclose(res.mensual.iloc[-1], 2, atol=1e-8)
    assert np.isclose(res.interanual.iloc[-1], 100*((1.02**12)-1), atol=1e-8)
    jan2021 = res.loc["2021-01-01", "acumulada"]
    assert np.isclose(jan2021, 2, atol=1e-8)
    jan2022 = res.loc["2022-01-01", "acumulada"]
    assert np.isclose(jan2022, 2, atol=1e-8)


def test_demo_proyeccion_pdf():
    demo = crear_demo()
    res = indicadores(demo.df)
    assert len(res) > 60
    a = anomalias(res.mensual)
    assert a.atipico.any()
    pron = calcular_pronostico(res.mensual, horizonte=6)
    assert len(pron["pronostico"]) == 6
    assert np.isfinite(pron["pronostico"].inflacion_proyectada).all()
    assert pron["mae"] >= 0
    texto = resumen(res, pron, a, demo.fuente)
    assert "SIMULADOS" in texto
    p = pdf_resumen(res, demo, pron, texto)
    assert p.startswith(b"%PDF")
    assert len(p) > 2500


def test_csv_y_simulador():
    d = crear_demo()
    csv = d.df.reset_index().to_csv(index=False).encode()
    loaded = desde_csv(csv)
    assert len(loaded.df) == len(d.df)
    valor = calcular_variacion_real(100_000, inflacion_porcentual=20, aumento_porcentual=10)
    assert np.isclose(valor["real"], 91666.6666667)
    assert np.isclose(valor["variacion_real"], -8.3333333333)


def test_datos_incompletos():
    dates = pd.date_range("2020-01-01", periods=50, freq="MS")
    d = pd.DataFrame({"fecha": dates, "ipc": np.arange(50) + 100})
    d = d.iloc[:-1].drop(index=12)
    with pytest.raises(ValueError, match="meses sin datos"):
        normalizar(d)


def test_descarga_api_mock():
    fechas = pd.date_range("2018-01-01", periods=70, freq="MS")
    valores = (100*np.cumprod(np.repeat(1.02, len(fechas)))).tolist()
    class Response:
        def __init__(self, output): self.output=output
        def raise_for_status(self): pass
        def json(self): return self.output
    class Sesion:
        def get(self, url, **kwargs):
            if "apis.datos.gob.ar" in url:
                return Response({"data": [[d.strftime("%Y-%m-%d"),v] for d,v in zip(fechas,valores)]})
            return Response({"dates": fechas.strftime("%Y-%m-%d").tolist(),
                             "variants": {"headline": {"values": valores}}})
    datos = descargar_datos(Sesion())
    assert len(datos.df) == 70
    assert "API" in datos.fuente

# Analizador de Inflación Argentina IA

Proyecto del segundo parcial **Programación para Economistas**. Es una **aplicación web funcional** hecha con Python y Streamlit, no un notebook ni un diseño estático.

## Qué hace

- Obtiene IPC nacional mediante la **API de Series de Tiempo de Datos Argentina**, id `148.3_INIVELNAL_DICI_M_26`, o un espejo identificado de la serie INDEC.
- Calcula variaciones mensual, interanual y acumulada desde diciembre anterior.
- Presenta gráficos interactivos y una tabla histórica descargable.
- Detecta observaciones inusuales con **Isolation Forest** (aprendizaje automático no supervisado).
- Evalúa ARIMA(1,0,0), ARIMA(2,0,0), ARIMA(1,0,1) y un método de persistencia con los 12 últimos meses de prueba, según MAE. Pronostica de 3 a 12 meses.
- Simula pérdida/ganancia de poder adquisitivo.
- Genera un informe automático y permite exportarlo a PDF/CSV.
- Opcionalmente permite redactar conclusiones con Gemini (API key propia).

## Opción A — Publicar como aplicación en internet (recomendada)

**No necesitás Google Colab.**

1. Creá una cuenta en [github.com](https://github.com) si todavía no tenés.
2. En GitHub, hacé clic en **New repository**. Nombre recomendado: `inflacion-argentina-ia`. Seleccioná *Public*.
3. Entrá al repositorio y seleccioná **Add file > Upload files**. Descomprimí el ZIP y subí **el contenido de la carpeta `Analizador_Inflacion_App`** (`app.py`, `inflacion_core.py`, `requirements.txt`, etc.), **no la carpeta ZIP**. Finalmente hacé clic en **Commit changes**.
4. Abrí [share.streamlit.io](https://share.streamlit.io/) e iniciá sesión con GitHub.
5. Elegí **Create app / Deploy app**, tu repositorio y la rama `main`. En **Main file path** escribí exactamente `app.py`.
6. Hacé clic en **Deploy**. La plataforma instalará las dependencias y te dará una dirección del tipo `https://...streamlit.app/` para abrir en cualquier navegador.
7. Al entrar, elegí **Datos oficiales en línea** en la barra lateral. Asegurate de que aparezca el mes correcto.

**No subas claves de Gemini al repositorio.** Podés usar el informe automático de la aplicación sin configurar Gemini.

## Opción B — Ejecutar en tu computadora Windows

1. Instalá Python 3.11+ desde [python.org](https://python.org) y marcá *Add Python to PATH*.
2. Descomprimí el ZIP.
3. Hacé doble clic en `lanzar_en_windows.bat` (instala dependencias la primera vez y abre la app).
4. Si no se abre el navegador, entrá a `http://localhost:8501`.

Alternativa desde una terminal ubicada en la carpeta:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## ¿Y Google Colab?

El notebook anterior documenta el desarrollo en Python, como solicita la consigna; **la app es la demostración interactiva**. Para la exposición, mostrala desde la dirección pública de Streamlit, y después explicá el código en `inflacion_core.py`.

## Cómo demostrarla (2–3 minutos)

1. Abrí **Panorama**, explicá las tres tasas de inflación y el último dato descargado.
2. Entrá en **Series históricas**, cambiá el indicador y descargá una tabla.
3. Mostrá en **IA y pronósticos** los meses atípicos, la comparación de modelos y la proyección a seis meses.
4. Modificá los valores de **Poder adquisitivo**.
5. En **Informe y descargas**, generá el PDF.

## Conexión y contingencia

- El modo por defecto necesita internet para consultar datos reales y **no inventa resultados** si las fuentes fallan.
- Si no hay conexión, elegí **Demo con datos simulados**. La pantalla lo indica expresamente: NO sirve para presentar cifras como si fueran del INDEC.
- También podés cargar tu propio CSV con columnas `fecha,ipc` y al menos 38 meses ordenados (fechas `YYYY-MM-01`). Su origen no se considera verificado.
- Si los datos se atrasan, la app muestra la fecha real de la última observación recibida.
- Gemini es totalmente opcional; al utilizarlo, la clave no debe guardarse en código público.

## Referencias

- API oficial: <https://apis.datos.gob.ar/series/api/series/?ids=148.3_INIVELNAL_DICI_M_26>
- Espejo: <https://ncachanosky.github.io/argentina-economic-monitor/data/cpi.json>
- Deploy Streamlit: <https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy>

## Limitaciones metodológicas

La evaluación mantiene un bloque de 12 meses fuera de muestra y utiliza un único origen de pronóstico, lo cual no equivale a validación temporal repetida. Los ARIMA pueden producir intervalos irreales en presencia de rupturas estructurales. Las anomalías son estadísticas, no evidencia de causas. Los modelos no incorporan cambios de política económica, expectativas ni escenarios internacionales. El método de persistencia no produce un intervalo probabilístico.
